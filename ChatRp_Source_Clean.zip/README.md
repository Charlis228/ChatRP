# ChatRp

Автор: CHARLIS228

Единый клиентский Fabric-мод для Minecraft 1.21.11 и Java 21. Сборка объединяет AdvancedChatCore, AdvancedChatBox, AdvancedChatFilters, AdvancedChatHUD и AdvancedChatLog в один jar с брендом ChatRp.

Что включено:
- единый `fabric.mod.json` с ID `chatrp`;
- русские ресурсы для ChatRp и встроенных AdvancedChat namespace;
- встроенные функции HUD, вкладок, фильтров, подсказок, голов игроков и журнала чата из исходных модулей;
- локальный конфиг `config/chatrp/config.json`;
- история `config/chatrp/chat_history.json`;
- иконки 64x64, 128x128 и 256x256;
- автоматический zip-бэкап после каждой сборки.

Сборка без Gradle:

```powershell
.\scripts\build-merged.ps1
```

Готовый файл появится в `build/libs/ChatRp-1.0.0+mc1.21.11.jar`, а бэкап сборки - в `backups/`.

Примечание по лицензии: встроенные AdvancedChat-компоненты распространяются под MPL-2.0, поэтому notice сохраняется внутри итогового jar.
